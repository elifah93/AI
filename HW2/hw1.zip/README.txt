Hi Dr. Grabowski,

For this homework I implemented everything you asked. I have tested the program, and it seems to work well.
The only thing I did not implemented is to print what are in the squares (pit, wumpus, percepts) of the grid.
I did not know, and I found about that today. The reason, I did not think that we need to put this things because the homework says
that the cave is absolutely dark, and the agent cannot see anything, so neither the user.
I tried to fixed it, but I would need to change almost all my code, since I used the percepts as an attribute of the
agent and not of the grid.
I am really sorry about this. For future homeworks I will read more carefully.

Thank you,
Elifaleth Cantu Alanis
